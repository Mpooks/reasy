package com.example.reasy;

public class eidopoihsh {

    private int idPelath;
    private String perigrafh;
    private String hmeromhnia;

    public eidopoihsh(int idPelath, String perigrafh, String hmeromhnia) {
        this.idPelath = idPelath;
        this.perigrafh = perigrafh;
        this.hmeromhnia = hmeromhnia;
    }


}
