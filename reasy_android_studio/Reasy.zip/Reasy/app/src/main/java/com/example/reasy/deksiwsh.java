package com.example.reasy;

public class deksiwsh {

    private String hmeromhnia;
    private String xwros;
    private int idKallitexnh;
    private int idXwrou;
    private int idCatering;
    private int idDeksiwshs;
    private int idPelath;

    public deksiwsh(int idDeksiwshs, int idPelath, String hmeromhnia, String xwros, int idKallitexnh, int idXwrou, int idCatering) {
        this.idDeksiwshs = idDeksiwshs;
        this.idPelath = idPelath;
        this.hmeromhnia = hmeromhnia;
        this.xwros = xwros;
        this.idKallitexnh = idKallitexnh;
        this.idXwrou = idXwrou;
        this.idCatering = idCatering;
    }
}
