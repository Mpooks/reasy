package com.example.reasy;

public class aksiologhsh {

    private int idKatasthmatos;
    private int idPelath;
    private int vathmos;
    private String sxolia;

    public aksiologhsh(int idKatasthmatos, int idPelath, int vathmos, String sxolia) {
        this.idKatasthmatos = idKatasthmatos;
        this.idPelath = idPelath;
        this.vathmos = vathmos;
        this.sxolia = sxolia;
    }


}
