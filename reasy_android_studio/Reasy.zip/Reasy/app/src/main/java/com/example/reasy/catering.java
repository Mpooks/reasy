package com.example.reasy;

public class catering {
    private String onoma;
    private int idCatering;
    private String eidosKouzinas;
    private float kostos;

    public catering(String onoma, int idCatering, String eidosKouzinas, float kostos) {
        this.onoma = onoma;
        this.idCatering = idCatering;
        this.eidosKouzinas = eidosKouzinas;
        this.kostos = kostos;
    }

}
